package com.ns.crud_postgresql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudPostgresqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
