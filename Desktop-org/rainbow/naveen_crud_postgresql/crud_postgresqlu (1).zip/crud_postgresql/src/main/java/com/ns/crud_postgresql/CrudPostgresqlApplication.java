package com.ns.crud_postgresql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudPostgresqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudPostgresqlApplication.class, args);
	}

}
