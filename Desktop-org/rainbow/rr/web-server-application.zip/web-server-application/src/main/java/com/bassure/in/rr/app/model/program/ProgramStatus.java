package com.bassure.in.rr.app.model.program;

public enum ProgramStatus {
    ACTIVE, INACTIVE
}
