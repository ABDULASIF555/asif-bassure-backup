/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.bassure.in.rr.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 * @author VaishnaviR
 */
@SpringBootApplication
public class SpringBootCrud {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootCrud.class, args);
    }
}
