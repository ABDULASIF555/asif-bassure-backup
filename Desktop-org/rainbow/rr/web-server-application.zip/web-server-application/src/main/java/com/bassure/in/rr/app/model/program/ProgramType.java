package com.bassure.in.rr.app.model.program;

public enum ProgramType {
    REWARD, RECOGNITION
}
